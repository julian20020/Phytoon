# Defino un diccionario para almacenar los productos del inventario
inventario = {}

# Función para agregar un producto al inventario
def agregar_producto():
    nombre = input("Ingrese el nombre del producto: ")
    cantidad = int(input("Ingrese la cantidad: "))
    precio = float(input("Ingrese el precio por unidad: "))
    # Agrego el producto al inventario
    inventario[nombre] = {'cantidad': cantidad, 'precio': precio}
    print(f"Producto '{nombre}' agregado al inventario.")

# Función para realizar una venta
def realizar_venta():
    nombre = input("Ingrese el nombre del producto a vender: ")
    if nombre in inventario:
        cantidad = int(input("Ingrese la cantidad a vender: "))
        if inventario[nombre]['cantidad'] >= cantidad:
            # Resto la cantidad vendida
            inventario[nombre]['cantidad'] -= cantidad
            print(f"Venta realizada: {cantidad} unidades de '{nombre}'.")
        else:
            print("No hay suficiente stock para realizar la venta.")
    else:
        print("El producto no existe en el inventario.")

# Función para consultar el inventario
def consultar_inventario():
    if inventario:
        print("\nInventario:")
        for nombre, detalles in inventario.items():
            print(f"{nombre} - Cantidad: {detalles['cantidad']} - Precio: ${detalles['precio']:.2f}")
    else:
        print("El inventario está vacío.")

# Función para verificar los productos bajos en stock
def verificar_bajo_stock():
    umbral = int(input("Ingrese el umbral de stock para verificar: "))
    productos_bajos = [nombre for nombre, detalles in inventario.items() if detalles['cantidad'] < umbral]
    if productos_bajos:
        print("\nProductos con bajo stock:")
        for producto in productos_bajos:
            print(f"- {producto} con {inventario[producto]['cantidad']} unidades.")
    else:
        print("No hay productos con bajo stock.")

# Función para mostrar el menú
def mostrar_menu():
    print("\n--- Menú de Gestión de Inventario ---")
    print("1. Agregar producto")
    print("2. Realizar venta")
    print("3. Consultar inventario")
    print("4. Verificar productos bajos en stock")
    print("5. Salir")
    opcion = input("Elija una opción (1-5): ")
    return opcion

# Función principal que coordina todo
def main():
    while True:
        # Muestra el menú y obtiene la opción elegida por el usuario
        opcion = mostrar_menu()

        if opcion == '1':  # Agregar producto
            agregar_producto()

        elif opcion == '2':  # Realizar venta
            realizar_venta()

        elif opcion == '3':  # Consultar inventario
            consultar_inventario()

        elif opcion == '4':  # Verificar productos bajos en stock
            verificar_bajo_stock()

        elif opcion == '5':  # Salir
            print("Saliendo del sistema. ¡Gracias por usar el sistema de gestión de inventario!")
            break

        else:
            print("Opción no válida. Por favor, elija una opción entre 1 y 5.")

# Inicio el programa
if __name__ == "__main__":
    main()
